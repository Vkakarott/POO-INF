public class Curso {
    String name;
    int duration;
    String institute;
    String modality;
}
